"""
下面的文件将会从csv文件中读取读取短信与电话记录，
你将在以后的课程中了解更多有关读取文件的知识。
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
任务4:
电话公司希望辨认出可能正在用于进行电话推销的电话号码。
找出所有可能的电话推销员:
这样的电话总是向其他人拨出电话，
但从来不发短信、接收短信或是收到来电


请输出如下内容
"These numbers could be telemarketers: "
<list of numbers>
电话号码不能重复，每行打印一条，按字典顺序排序后输出。
"""

def remove_duplicates(tokens):
    '''
    remove duplicates
    '''
    unique_list = []
    for token in tokens:
        if token not in unique_list:
            unique_list.append(token)
    unique_list.sort()
    return unique_list


def get_sales_number(calls, texts):
    calling_numbers = []
    called_numbers  = []
    texting_numbers = []
    texted_numbers  = []
    
    for call in calls:
        # 向其他人拨出电话的140开头电话
        if call[0].startswith("140") and call[0] not in calling_numbers:
            calling_numbers.append(call[0])
                
        # 收到来电的140开头电话
        if call[1].startswith("140") and call[1] not in called_numbers:
            called_numbers.append(call[1])
    calling_numbers.sort()
    
    for text in texts:
        # 发短信的140开头电话
        if text[0].startswith("140") and text[0] not in texting_numbers:
            texting_numbers.append(text[0])
            
        # 接收短信的140开头电话
        if text[1].startswith("140") and text[1] not in texted_numbers:
            texted_numbers.append(text[1])
    
    # 收到来电，发短信和接收短信的140开头的电话汇总去重复
    numbers = called_numbers + texting_numbers + texted_numbers
    unique_number_list = remove_duplicates(numbers)
    
    for calling_number in calling_numbers:
        # 如果拨出的140电话从没有收到来电，发短信和接收短信
        if calling_number not in unique_number_list:
            print(calling_number)
    

print("These numbers could be telemarketers: ")
get_sales_number(calls, texts)

    
    
    
    
    
    
    
    
    
